# Cup of Cat Cafe

SECTION : BSIT - 307
Members:

     Names          |               Github Links            |                             Contributions / Scope of Work                 
Xai Delos Reyes     |     https://github.com/Xaikov563      |     Database/Backend Integrator, Website Concepts, Frontend Integrate to Backend
Genevieve Subito    |     https://github.com/kznkma         |     Frontend Head and Editor, In-charge of CSS and Javascripts
Darrel Cardinales   |     https://github.com/Darkov2005     |     Frontend Editor, Website Concepts
Remie Vegas         |     https://github.com/remieross      |     Frontend Editor, Website Concepts
Rhodge Violago      |     https://github.com/Drei-Raj       |     Frontend Editor, Website Concepts
Rafix Bin Rene      |     https://github.com/rafixbinrene   |     Frontend Editor, Website Concepts


Checklist :

1. Edit Html, Css Files

    // Front End //
      - ACTUAL Products and Merch with our website logo ✅
      - Gallery ✅
      - About Page ✅
      - Contacts ✅
      - Home Page 
      - Cart ✅
      - Navbar ✅ Responsive ❌ not yet
      - Footer ✅
      - Find a cafe, button ✅
      - Merchandise ✅
      - Actual Products in Store ✅ 
      - Responsiveness ✅ 
    

     // Back End //
      - Login/Logout/Register Page ✅
      - Authentication ✅
      - Page Restriction ✅
      - Customer and Admin ✅
      - Paypal System ✅
2. Add other Features ✅
3. Aralin yung Code